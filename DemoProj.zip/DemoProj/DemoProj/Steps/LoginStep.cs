﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace DemoProj.Steps
{
    [Binding]
    public sealed class LoginStep
    {
        
        private readonly ScenarioContext _scenarioContext;
        IWebDriver webDriver;
        public LoginStep(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Given(@"I launch the application")]
        public void GivenILaunchTheApplication()
        {
            webDriver = new ChromeDriver();
            webDriver.Navigate().GoToUrl("http://eaapp.somee.com/");
        }

        [Given(@"I click on login link")]
        public void GivenIClickOnLoginLink()
        {
            webDriver.FindElement(By.XPath("/html/body/div[1]/div/div[2]/ul[2]/li[2]/a")).Click();
        }

        [When(@"I enter the username and password")]
        public void WhenIEnterTheUsernameAndPassword()
        {
            webDriver.FindElement(By.XPath("/html/body/div[2]/div/div[2]/section/form/div[1]/div/input")).Click();
            webDriver.FindElement(By.XPath("/html/body/div[2]/div/div[2]/section/form/div[1]/div/input")).SendKeys("admin");
            webDriver.FindElement(By.XPath("/html/body/div[2]/div/div[2]/section/form/div[2]/div/input")).Click();
            webDriver.FindElement(By.XPath("/html/body/div[2]/div/div[2]/section/form/div[2]/div/input")).SendKeys("password");
            
        }

        [Then(@"I click on login button")]
        public void ThenIClickOnLoginButton()
        {
            webDriver.FindElement(By.XPath("/html/body/div[2]/div/div[2]/section/form/div[4]/div/input")).Click();
        }

        [Then(@"I should see homepage and logoff the application")]
        public void ThenIShouldSeeHomepageAndLogoffTheApplication()
        {
            //String actualTitle = webDriver.Title;
            //String expectedTitle = "Home";
            //if(!actualTitle.Equals(expectedTitle))
            //{
            //    Console.WriteLine("Title not matched");
            //}
            webDriver.FindElement(By.XPath("/html/body/div[1]/div/div[2]/form/ul/li[2]/a")).Click();
            webDriver.Close();
        }

       }
}
